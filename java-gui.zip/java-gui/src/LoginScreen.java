import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginScreen extends JFrame {
    JTextField usernameTextField;
    JPasswordField passwordField;

    public LoginScreen() {
        setSize(700, 400);
        setLocation(600, 200);
        setTitle("Login Screen");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER));

        JPanel boxPanel = new JPanel();
        boxPanel.setLayout(new BoxLayout(boxPanel, BoxLayout.Y_AXIS));

        boxPanel.add(getHeader());
        boxPanel.add(getUsernamePanel());
        boxPanel.add(getPasswordPanel());
        boxPanel.add(getLoginButtonPanel());

        add(boxPanel);
    }

    private JPanel getHeader() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBorder(new EmptyBorder(10, 0, 10, 0));
        JLabel headerLabel = new JLabel("RD Login");
        headerLabel.setForeground(Color.RED);
        headerLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 36));
        panel.add(headerLabel);
        return panel;
    }

    private JPanel getUsernamePanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBorder(new EmptyBorder(10, 0, 10, 0));
        panel.add(new JLabel("Username: "));
        usernameTextField = new JTextField(16);
        panel.add(usernameTextField);
        return panel;
    }

    private JPanel getPasswordPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBorder(new EmptyBorder(10, 0, 10, 0));
        panel.add(new JLabel("Password: "));
        passwordField = new JPasswordField(16);
        panel.add(passwordField);
        return panel;
    }

    private JPanel getLoginButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBorder(new EmptyBorder(20, 0, 30, 0));
        GradientButton loginButton = new GradientButton("Login");
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.animateHover(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.animateHover(false);
            }
        });
        loginButton.addActionListener(action -> {
            String username = usernameTextField.getText();
            char[] password = passwordField.getPassword();

            if (authenticate(username, password)) {
                if (username.equals("Admin")) {
                    // Redirect to the admin dashboard
                    AdminDashboard adminDashboard = new AdminDashboard();
                    adminDashboard.setVisible(true);
                } else if (username.equals("Staff")) {
                    // Redirect to the staff dashboard
                    StaffDashboard staffDashboard = new StaffDashboard();
                    staffDashboard.setVisible(true);
                }
                dispose();
            } else {
                // Display an error message for invalid credentials
                JOptionPane.showMessageDialog(LoginScreen.this, "Invalid username or password", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(loginButton);
        return panel;
    }

    private class GradientButton extends JButton {
        private boolean hover = false;

        public GradientButton(String text) {
            super(text);
            setContentAreaFilled(false);
        }

        public void animateHover(boolean hover) {
            this.hover = hover;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (getModel().isPressed()) {
                g.setColor(new Color(0, 82, 164)); // Darker blue when pressed
            } else if (hover) {
                g.setColor(new Color(0, 153, 255)); // Lighter blue on hover
            } else {
                g.setColor(Color.LIGHT_GRAY);
            }
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            super.paintComponent(g);
        }
    }

    // Implement an authenticate method to validate user credentials
    private boolean authenticate(String username, char[] password) {
        // Implement user authentication logic here
        // Check if the provided username and password match the fixed credentials
        if (username.equals("Admin") && new String(password).equals("Admin123")) {
            return true;
        } else if (username.equals("Staff") && new String(password).equals("Staff123")) {
            return true;
        } else {
            return false;
        }
    }



}
