public class Main {
    public static void main(String[] args) {
        WelcomeScreen welcomeScreen = new WelcomeScreen();
        welcomeScreen.setVisible(true);

        //LoginScreen loginScreen = new LoginScreen();
        //loginScreen.setVisible(true);
    }
}