import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ProductListScreen extends JFrame {
    private ArrayList<Product> products;

    public ProductListScreen(ArrayList<Product> products) {
        setTitle("Product List");
        setSize(800, 600);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        this.products = products;

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");

        searchButton.addActionListener(e -> {
            String searchText = searchField.getText().toLowerCase();
            filterProducts(searchText);
        });

        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        JPanel productPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 20));

        for (Product product : products) {
            JPanel productItem = new JPanel(new BorderLayout());

            JLabel productNameLabel = new JLabel(product.getName(), SwingConstants.CENTER);
            productNameLabel.setPreferredSize(new Dimension(100, 20));

            JButton productButton = new JButton();
            productButton.setPreferredSize(new Dimension(100, 100));
            productButton.setIcon(new ImageIcon(product.getImagePath()));

            productButton.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    displayProductDetails(product);
                }
            });

            productItem.add(productButton, BorderLayout.NORTH);
            productItem.add(productNameLabel, BorderLayout.CENTER);

            productPanel.add(productItem);
        }

        JScrollPane scrollPane = new JScrollPane(productPanel);

        setLayout(new BorderLayout());
        add(searchPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
    }

    private void filterProducts(String searchText) {
        for (Component component : getContentPane().getComponents()) {
            if (component instanceof JScrollPane) {
                JPanel productPanel = (JPanel) ((JScrollPane) component).getViewport().getView();
                for (Component productItem : productPanel.getComponents()) {
                    if (productItem instanceof JPanel) {
                        JLabel productNameLabel = (JLabel) ((JPanel) productItem).getComponent(1);
                        productNameLabel.setVisible(productNameLabel.getText().toLowerCase().contains(searchText));
                    }
                }
            }
        }
    }

    private void displayProductDetails(Product product) {
        JOptionPane.showMessageDialog(this,
                "Product: " + product.getName() +
                        "\nPrice: $" + product.getPrice() +
                        "\nQuantity: " + product.getQuantity(),
                "Product Details",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ArrayList<Product> products = new ArrayList<>();
            products.add(new Product("Sweet Corn", 2.99, 50, "sweetcorn.jpg"));
            products.add(new Product("Popcorn", 1.99, 100, "popcorn.jpg"));
            products.add(new Product("Cool Drinks", 1.49, 75, "coke.jpg"));
            // Add more products with image paths here

            ProductListScreen productListScreen = new ProductListScreen(products);
            productListScreen.setVisible(true);
        });
    }
}

class Product {
    private String name;
    private double price;
    private int quantity;
    private String imagePath;

    public Product(String name, double price, int quantity, String imagePath) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.imagePath = imagePath;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getImagePath() {
        return imagePath;
    }
}
