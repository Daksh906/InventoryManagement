import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

public class StaffDashboard extends JFrame {
    public StaffDashboard() {
        setTitle("Staff Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Create a welcome label for the staff
        JLabel welcomeLabel = new JLabel("Welcome, Staff!");
        welcomeLabel.setFont(new Font("Helvetica", Font.BOLD, 24));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);

        // Create a panel for staff-specific features
        JPanel staffFeaturesPanel = new JPanel();
        staffFeaturesPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        staffFeaturesPanel.setBorder(new EmptyBorder(20, 0, 20, 0));

        // Create the "Place Order" button
        JButton placeOrderButton = new JButton("Place Order");
        placeOrderButton.addActionListener(e -> {
            ArrayList<Product> products = new ArrayList<>();
            // Populate the products list with sample data
            products.add(new Product("Sweet Corn", 2.99, 50, "sweetcorn.jpg"));
            products.add(new Product("Popcorn", 1.99, 100, "popcorn.jpg"));
            products.add(new Product("Cool Drinks", 1.49, 75, "coke.jpg"));
            // Add more products with image paths here

            ProductListScreen productListScreen = new ProductListScreen(products);
            productListScreen.setVisible(true);
        });

        // Create the "Bill" or "Point of Sale" button
        JButton billButton = new JButton("Bill / Point of Sale");
        billButton.addActionListener(e -> {
            // Add code to open the bill or point of sale screen
            // For example, you can create a new JFrame for it
            // BillScreen billScreen = new BillScreen();
            // billScreen.setVisible(true);
        });

        // Add the buttons to the staff features panel
        staffFeaturesPanel.add(placeOrderButton);
        staffFeaturesPanel.add(billButton);

        // Create a "Logout" button
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> {
            // Handle the logout action here (e.g., return to the login screen)
            LoginScreen loginScreen = new LoginScreen();
            loginScreen.setVisible(true);
            dispose();
        });

        // Add components to the main panel
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);
        mainPanel.add(staffFeaturesPanel, BorderLayout.CENTER);
        mainPanel.add(logoutButton, BorderLayout.SOUTH);

        add(mainPanel);

        // Center the window on the screen
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StaffDashboard staffDashboard = new StaffDashboard();
            staffDashboard.setVisible(true);
        });
    }
}
