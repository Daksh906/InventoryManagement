import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import javax.swing.ImageIcon;

public class WelcomeScreen extends JFrame {
    public WelcomeScreen() {
        setSize(900, 500);
        setLocation(500, 200);
        setTitle("Cafeteria Inventory Management");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create a JPanel to hold your image and other components
        JPanel contentPanel = new JPanel(new BorderLayout());

        // Load the image
        //ImageIcon originalImageIcon = new ImageIcon("D:\\Photoshop\\RAJDHANI\\raw images\\rd1.jpg"); // Replace with the actual image path
        ImageIcon originalImageIcon = new ImageIcon("D:\\Photoshop\\RAJDHANI\\raw images\\RD0.png"); // Replace with the actual image path
        // Calculate the desired width and height for your image
        int newWidth = 300; // Adjust this value as needed
        int newHeight = 200; // Adjust this value as needed

        // Resize the image
        Image originalImage = originalImageIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedImageIcon = new ImageIcon(resizedImage);

        // Add the resized image to your welcome screen
        JLabel imageLabel = new JLabel(resizedImageIcon);
        contentPanel.add(imageLabel, BorderLayout.NORTH);

        JPanel boxPanel = new JPanel();
        boxPanel.setLayout(new BoxLayout(boxPanel, BoxLayout.Y_AXIS));
        boxPanel.setBorder(new EmptyBorder(30, 10, 30, 10));

        JLabel welcomeLabel = new JLabel("Welcome to Rajdhani Deluxe Cafeteria");
        welcomeLabel.setForeground(Color.DARK_GRAY);
        welcomeLabel.setFont(new Font("Helvetica", Font.BOLD, 32));

        JPanel labelPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        labelPanel.setBorder(new EmptyBorder(20, 0, 20, 0));
        labelPanel.add(welcomeLabel);
        boxPanel.add(labelPanel);

        JTextArea textArea = new JTextArea("Cafeteria Inventory Management System");
        textArea.setEditable(false);
        textArea.setFont(new Font("Helvetica", Font.PLAIN, 18));
        textArea.setLineWrap(false);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(new Color(240, 240, 240));

        JPanel textAreaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        textAreaPanel.setBorder(new EmptyBorder(10, 0, 30, 0));
        textAreaPanel.add(textArea);
        boxPanel.add(textAreaPanel);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton continueButton = new JButton("Get Started");
        continueButton.setBackground(new Color(0, 102, 204));
        continueButton.setForeground(Color.WHITE);
        continueButton.setFont(new Font("Helvetica", Font.BOLD, 18));
        continueButton.addActionListener(action -> {
            System.out.println("Get Started Button Clicked");

            LoginScreen loginScreen = new LoginScreen();
            loginScreen.setVisible(true);
            dispose();
        });
        buttonPanel.add(continueButton);
        boxPanel.add(buttonPanel);
        contentPanel.add(boxPanel, BorderLayout.CENTER);

        add(contentPanel);
    }


}